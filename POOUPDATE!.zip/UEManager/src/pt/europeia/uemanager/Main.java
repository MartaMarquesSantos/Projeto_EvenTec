package pt.europeia.uemanager;
	
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import pt.europeia.uemanager.controllers.BookGameWeek2Controller;
import pt.europeia.uemanager.controllers.BookGameWeekController;
import pt.europeia.uemanager.controllers.ChooseEventsLisbonController;
import pt.europeia.uemanager.controllers.EventController;
import pt.europeia.uemanager.controllers.EventsLisbonController;
import pt.europeia.uemanager.controllers.EventsPortoController;
import pt.europeia.uemanager.controllers.LoginController;
import pt.europeia.uemanager.controllers.ParticipanteController;
import pt.europeia.uemanager.controllers.RegisterController;
import pt.europeia.uemanager.controllers.WorkshopsGameWeekController;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;


public class Main extends Application {
	
	private static Stage mainStage;
	
	@Override
	public void start(Stage primaryStage) {
		mainStage = primaryStage;
		Scene scene = new Scene(new Pane());
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		mainStage.setScene(scene);
		openLogin();
		mainStage.show();
	}

	public static void openLogin() {
		String urlStr = "views/loginview.fxml";
		Object cont = new LoginController();
		changeWindow(urlStr, cont);
	}
	
	public static void openRegisterWindow() {
		String urlStr = "views/registoview.fxml";
		Object cont =new RegisterController();
		changeWindow(urlStr, cont);
	}
	
	public static void openEventsWindow(String login) {
		String urlStr = "views/EventsView.fxml";
		Object cont =new EventController();
		changeWindow(urlStr, cont);
	}
	
	public static void openEventsLisbonWindow(String locals) {
		String urlStr = "views/EventsLisbonView.fxml";
		Object cont =new EventsLisbonController();
		changeWindow(urlStr, cont);
	}
	
	public static void openEventsPortoWindow(String locals) {
		String urlStr = "views/EventsPortoView.fxml";
		Object cont =new EventsPortoController();
		changeWindow(urlStr, cont);
	}
	
	public static void openChooseEventsLisbonWindow(String locals) {
		String urlStr = "views/ChooseEventsLisbonView.fxml";
		Object cont =new ChooseEventsLisbonController();
		changeWindow(urlStr, cont);
	}
	
	public static void openBookGameWeekWindow(String locals) {
		String urlStr = "views/BookGameWeekView.fxml";
		Object cont =new BookGameWeekController();
		changeWindow(urlStr, cont);
	}
	
	public static void openBookGameWeek2Window(String locals) {
		String urlStr = "views/BookGameWeek2View.fxml";
		Object cont =new BookGameWeek2Controller();
		changeWindow(urlStr, cont);
	}
	
	public static void openWorkshopsGameWeekWindow(String locals) {
		String urlStr = "views/WorkshopsGameWeek.fxml";
		Object cont =new WorkshopsGameWeekController();
		changeWindow(urlStr, cont);
	}
	
	private static void changeWindow(String urlStr, Object cont) {
		try {
			URL path = Main.class.
					getResource(urlStr);
			FXMLLoader loader = new FXMLLoader(path);
			loader.setController(cont);
			Parent root = loader.load();
			mainStage.getScene().setRoot(root);
			mainStage.sizeToScene();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public static void main(String[] args) {
		launch(args);
	

	}
}
