package pt.europeia.uemanager.models.daos;

public class ClienteDAO {

}
