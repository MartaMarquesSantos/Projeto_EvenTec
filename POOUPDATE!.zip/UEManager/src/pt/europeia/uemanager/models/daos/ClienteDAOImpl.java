package pt.europeia.uemanager.models.daos;

public interface ClienteDAOImpl {

}
