package pt.europeia.uemanager.models;

public class Evento {
	public String nome;
	public String descricao;
	public int horario;
	public String local;
	public String hotel;
	public int DataEvento;
	
	public Evento(String nome, String descricao, int horario, String local, String hotel, int DataEvento) { 
		this.nome = nome;
		this.descricao = descricao;
		this.horario = horario;
		this.local = local;
		this.hotel = hotel;
		this.DataEvento = DataEvento;
	}

	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getHorario() {
		return horario;
	}

	public String getLocal() {
		return local;
	}

	public String getHotel() {
		return hotel;
	}

	public int getDataEvento() {
		return DataEvento;
	}
	
}
