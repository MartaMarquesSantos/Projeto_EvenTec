package pt.europeia.uemanager.models;

public class Cliente {
	
	protected String nome;
	protected String email;
	protected String pass;
	protected String morada;
	public Cliente(String nome, String email,
			String pass, String morada) {
		this.nome = nome;
		this.email = email;
		this.pass = pass;
		this.morada = morada;
	}
	public String getNome() {
		return nome;
	}
	public String getEmail() {
		return email;
	}
	public String getPass() {
		return pass;
	}
	public String getMorada() {
		return morada;		
	}
}
