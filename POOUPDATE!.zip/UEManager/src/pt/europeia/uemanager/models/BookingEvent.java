package pt.europeia.uemanager.models;

public class BookingEvent extends Evento  
	{
	public int clienteId;
	public int bookingDate;
	public int bookingLocal;
	public boolean certificate;
	public boolean shuttle;
	public boolean dinner;
	
	
	public BookingEvent(String nome, String descricao, int horario, String local, 
			String hotel, int DataEvento, int clienteId, int bookingDate, int bookingLocal,
			boolean certificate, boolean shuttle, boolean dinner)
	{	
		super(nome, descricao, horario, local,hotel, DataEvento);
		this.clienteId = clienteId;
		this.bookingDate = bookingDate;
		this.bookingLocal = bookingLocal;
		this.certificate = certificate;
		this.shuttle = shuttle;
		this.dinner = dinner;
	}
		

	public int getClienteId() {
		return clienteId;
	}


	public int getBookingDate() {
		return bookingDate;
	}


	public void setBookingDate(int bookingDate) {
		this.bookingDate = bookingDate;
	}


	public int getBookingLocal() {
		return bookingLocal;
	}
	
	public void setBookingLocal(int bookingLocal) {
		this.bookingLocal = bookingLocal;
	}

	public boolean isCertificate() {
		return certificate;
	}
 
	public void setCertificate(boolean certificate) {
		this.certificate = certificate;
	}

	public boolean isShuttle() {
		return shuttle;
	}


	public void setShuttle(boolean shuttle) {
		this.shuttle = shuttle;
	}



	public boolean isDinner() {
		return dinner;
	}



	public void setDinner(boolean dinner) {
		this.dinner = dinner;
	}
	
	
}

					
			
			
			
			
			
			
			