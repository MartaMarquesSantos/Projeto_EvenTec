package pt.europeia.uemanager.models;

public class Participante extends Cliente {
	public int clienteid;
	public int username;
	public String password;
	
	public Participante(String nome, String email,
			String pass, String morada, int clienteid, int username, String password) {
		super(nome, email, pass, morada);
		this.clienteid = clienteid;
		this.username = username;
		this.password = password; 
	}
	 
/* public Participante (int clienteid, String email) {
	this.clienteid = clienteid;
	this.email = email;
	this.password = generatePassword();
	
}


public static generatePassword() {
	String password = "";
	String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	int passLenght = 8;
	int index = 0;
	for (int i=0; i<passLenght;i++) {
		index = (int)(Math.random()* alpha.length());
		password += alpha.substring(index, index+1);
	}
	return password;
	*/
	

	public int getClienteid() {
		return clienteid;
	}
	
	public int getUsername() {
		return username;
	}
	
	
	public String getPassword() {
		return password;
	}
	
	
	
	}

