package pt.europeia.uemanager.models;

public class Palestrante extends Cliente {
	public int clienteid;
	public String profissao;
	
	
	public Palestrante (String nome, String email,
			String pass, String morada, int clienteid, String profissao) {
		super(nome, email, pass, morada);
		this.clienteid = clienteid;
		this.profissao = profissao;
	}


	public int getClienteid() {
		return clienteid;
	}

	public String getProfissao() {
		return profissao;
	
	}
	
	
}
