package pt.europeia.uemanager.controllers;

import java.net.URL;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import pt.europeia.uemanager.Main;

public class ParticipanteController {

	private String username;


	public ParticipanteController(String username) {
		this.username = username;

	}

	@FXML
	private Label userL;

	
	@FXML
	private void initialize() {
		userL.setText("Utilizador: "+username);
	}


	@FXML
	private void logout() {
		Main.openLogin();
	}

}
