package pt.europeia.uemanager.controllers;

public class BookingEventController {

}
