package pt.europeia.uemanager.controllers;

public class BookGameWeek2Controller {

}
