package pt.europeia.uemanager.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import pt.europeia.uemanager.Main;

public class EventController {
	
	 @FXML
	 private TextField localsTF;
	 
	 @FXML
		private void previews() {
			Main.openLogin();
	
	 }
		@FXML
		private void event() {
			
			String locals = localsTF.getText();
			
			Main.openEventsLisbonWindow(locals);
		}	


}
