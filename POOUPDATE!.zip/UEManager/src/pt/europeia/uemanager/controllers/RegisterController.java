package pt.europeia.uemanager.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import pt.europeia.uemanager.Main;

public class RegisterController {
		
    @FXML
    private TextField nomeTF;

    @FXML
    private TextField emailTF;

    @FXML
    private TextField moradaTF;
		
	@FXML
	private TextField loginTF;
		
	@FXML
	private TextField passwordTF;

	@FXML
	private void back() {
		Main.openLogin();	
	}
	@FXML
	private void register() {
		
		String nome = nomeTF.getText();
		
		Main.openEventsWindow(nome);
	}	

}