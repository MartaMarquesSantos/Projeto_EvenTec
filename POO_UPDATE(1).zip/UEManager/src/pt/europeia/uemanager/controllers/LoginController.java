package pt.europeia.uemanager.controllers;

import java.net.URL;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pt.europeia.uemanager.Main;

public class LoginController {

	@FXML
	private TextField usernameTF;
	@FXML
	private TextField passwordTF;


	@FXML
	private void login() {
		String username = usernameTF.getText();
		String password = passwordTF.getText();

		if (username.equals("admin") &&
				password.equals("admin")) {
			Main.openEventsWindow(username);
		} else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setHeaderText("Username: "+username+"\nPassword :"+password);
			alert.showAndWait();
		}

	}
	@FXML
	private void registo() {
		Main.openRegisterWindow();
	}
	
}
