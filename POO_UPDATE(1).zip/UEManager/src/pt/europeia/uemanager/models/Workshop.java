package pt.europeia.uemanager.models;

public class Workshop {

	public String nome;
	public int horario;
	
	
	public Workshop (String nome, int horario)
	
	{
		this.nome = nome;
		this.horario = horario;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getHorario() {
		return horario;
	}

	public void setHorario(int horario) {
		this.horario = horario;
	}
	
	
	
}
