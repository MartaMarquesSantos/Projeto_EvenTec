package pt.europeia.uemanager.models.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnecter {
	private static final String URL = "jdbc:mysql://remotemysql.com:3306/1QZJZvezkW?useSSL=false";
	private static final String PASS = "9plQRbmutg";
	private static final String USER = "1QZJZvezkW";

	private static Connection connector;
	private DBConnecter () {}
	
	public static Connection getConnection() {
		try {
			if (connector == null ||
					connector.isClosed())
				connector = DriverManager.
					getConnection(URL,USER,PASS);
			return connector;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}