package pt.europeia.uemanager.models;

public class BookingWorkshop extends Workshop {
	
	public int eventId;
	public int bookingDate;
	public int clienteId;
	public boolean certificate;
	public int DataWorkshop;
	
	
	public BookingWorkshop (String nome, int horario, int eventId, int bookingDate, 
			int clienteId, boolean certificate, int DataWorkshop) {
		super(nome, horario);
		this.eventId =eventId;
		this.bookingDate = bookingDate;
		this.clienteId = clienteId;
		this.certificate = certificate;
		this.DataWorkshop = DataWorkshop;
		
	}


	public int getEventId() {
		return eventId;
	}



	public int getBookingDate() {
		return bookingDate;
	}


	public void setBookingDate(int bookingDate) {
		this.bookingDate = bookingDate;
	}


	public int getClienteId() {
		return clienteId;
	}



	public boolean isCertificate() {
		return certificate;
	}


	public void setCertificate(boolean certificate) {
		this.certificate = certificate;
	}

	
	public int getDataWorkshop() {
		return DataWorkshop;
		
	}
	

}
